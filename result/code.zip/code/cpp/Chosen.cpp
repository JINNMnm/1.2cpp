#include "../hpp/Chosen.hpp"
#include <iostream>
using namespace std;

Chosen::Chosen(){
    //���캯��
    bh = 0;
}